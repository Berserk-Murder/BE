const router = require("express").Router();

const CommentsController = require("../controller/CommentsController");
const { authMiddleware } = require("../helpers/authMiddleware");

router.post("/post", authMiddleware, CommentsController.create);

router.get("/:id", authMiddleware, CommentsController.read);

router.delete("/del/:id", authMiddleware, CommentsController.del);

module.exports = router;